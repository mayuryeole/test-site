<?php

namespace App\PiplModules\wishlist\Controllers;

use Auth;
use Auth\User;
use App\Http\Requests;
use App;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Storage;
use App\PiplModules\coupon\Models\Coupon;
use Mail;
use Image;
use Datatables;
use GlobalValues;
use App\PiplModules\emailtemplate\Models\EmailTemplate;
use App\User as MainUser;
use App\UserInformation;
use Illuminate\Routing\UrlGenerator;
use App\PiplModules\coupon\Models\CouponUser;
use App\PiplModules\wishlist\Models\Wishlist;
use App\PiplModules\coupon\SendCouponEmail;

class WishlistController extends Controller {


    public function addToWishlist(Request $request) {
        if(Auth::user())
        {
           $product_id=$request->product_id;
           $customer_id=Auth::user()->id;
           $is_already_added=  Wishlist::where('customer_id',$customer_id)->where('product_id',$product_id)->first();
           if(isset($is_already_added) && count($is_already_added)>0)
           {
              $is_already_added->delete(); 
              return "Deleted From Wishlist"; 
           }else{
                $wishlist_obj=new Wishlist();
                $wishlist_obj->customer_id=$customer_id;
                $wishlist_obj->product_id=$product_id;
                $wishlist_obj->save();
                return "Added In Wishlist"; 
           }
          
        }else {
            $errorMsg = "Error! Your Session timed out.";
            Auth::logout();
            return redirect("/")->with("issue-profile", $errorMsg);
        }
      
    }

   
 

}
