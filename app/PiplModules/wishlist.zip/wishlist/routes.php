<?php
Route::group(array('module'=>'wishlist','namespace' => 'App\PiplModules\wishlist\Controllers','middleware'=>'web'), function() {
        //Your routes belong to this module.
	Route::get("/ajax-add-product-in-wishlist","WishlistController@addToWishlist");
	
	
});